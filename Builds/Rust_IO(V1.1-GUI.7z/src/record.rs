use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use hound;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

pub fn record_audio(file_path: &str, is_recording_flag: Arc<AtomicBool>) -> Result<(), Box<dyn std::error::Error>> {
    let host = cpal::default_host();
    let device = host.default_input_device().expect("Failed to get default input device");
    let config = device.default_input_config()?;

    let sample_format = config.sample_format();
    let sample_rate = config.sample_rate().0;
    let channels = config.channels();

    println!("Recording to {} with format {:?}", file_path, sample_format);
    let spec = hound::WavSpec {
        channels,
        sample_rate,
        bits_per_sample: 16,
        sample_format: hound::SampleFormat::Int,
    };
    let writer = Arc::new(std::sync::Mutex::new(
        hound::WavWriter::create(file_path, spec)?
    ));

    let is_recording_clone = is_recording_flag.clone();

    let stream = match sample_format {
        cpal::SampleFormat::I16 => {
            let writer = Arc::clone(&writer);
            device.build_input_stream(
                &config.config(),
                move |data: &[i16], _| {
                    if is_recording_clone.load(Ordering::Relaxed) {
                        let mut writer = writer.lock().unwrap();
                        for &sample in data {
                            writer.write_sample(sample).unwrap();
                        }
                    }
                },
                |err| eprintln!("Error: {:?}", err),
                None,
            )?
        },
        cpal::SampleFormat::F32 => {
            let writer = Arc::clone(&writer);
            device.build_input_stream(
                &config.config(),
                move |data: &[f32], _| {
                    if is_recording_clone.load(Ordering::Relaxed) {
                        let mut writer = writer.lock().unwrap();
                        for &sample in data {
                            let sample = (sample * i16::MAX as f32) as i16;
                            writer.write_sample(sample).unwrap();
                        }
                    }
                },
                |err| eprintln!("Error: {:?}", err),
                None,
            )?
        },
        cpal::SampleFormat::U16 => {
            let writer = Arc::clone(&writer);
            device.build_input_stream(
                &config.config(),
                move |data: &[u16], _| {
                    if is_recording_clone.load(Ordering::Relaxed) {
                        let mut writer = writer.lock().unwrap();
                        for &sample in data {
                            let sample = sample as i16 - i16::MAX;
                            writer.write_sample(sample).unwrap();
                        }
                    }
                },
                |err| eprintln!("Error: {:?}", err),
                None,
            )?
        },
        _ => return Err("Unsupported sample format".into()),
    };

    stream.play()?;

    // Wait while recording is true
    while is_recording_flag.load(Ordering::Relaxed) {
        std::thread::sleep(std::time::Duration::from_millis(100));
    }

    // Ensure the stream is dropped and the file is properly closed
    drop(stream);
    drop(writer);
    
    Ok(())
}
