mod record;
mod playback;

use eframe::egui;
use record::record_audio;
use playback::playback_audio;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;

struct AudioApp {
    is_recording: Arc<AtomicBool>,
    is_playing: Arc<AtomicBool>,
    recording_thread: Option<thread::JoinHandle<()>>,
    playback_thread: Option<thread::JoinHandle<()>>,
    should_cleanup_recording: bool,
    should_cleanup_playback: bool,
}

impl Default for AudioApp {
    fn default() -> Self {
        Self {
            is_recording: Arc::new(AtomicBool::new(false)),
            is_playing: Arc::new(AtomicBool::new(false)),
            recording_thread: None,
            playback_thread: None,
            should_cleanup_recording: false,
            should_cleanup_playback: false,
        }
    }
}

impl eframe::App for AudioApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Handle thread cleanup first
        if self.should_cleanup_recording {
            if let Some(handle) = self.recording_thread.take() {
                if handle.is_finished() {
                    let _ = handle.join();
                    self.should_cleanup_recording = false;
                }
            }
        }

        if self.should_cleanup_playback {
            if let Some(handle) = self.playback_thread.take() {
                if handle.is_finished() {
                    let _ = handle.join();
                    self.should_cleanup_playback = false;
                }
            }
        }

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("Audio Recorder and Player");
            ui.add_space(20.0);

            let recording = self.is_recording.load(Ordering::Relaxed);
            let playing = self.is_playing.load(Ordering::Relaxed);

            // Record button
            if recording {
                if ui.button("Stop Recording").clicked() {
                    self.is_recording.store(false, Ordering::Relaxed);
                    self.should_cleanup_recording = true;
                }
            } else if !playing && ui.button("Record").clicked() {
                let is_recording = Arc::clone(&self.is_recording);
                self.is_recording.store(true, Ordering::Relaxed);
                self.recording_thread = Some(thread::spawn(move || {
                    match record_audio("output.wav", is_recording) {
                        Ok(_) => println!("Recording completed successfully"),
                        Err(e) => eprintln!("Error during recording: {:?}", e),
                    }
                }));
            }

            ui.add_space(10.0);

            // Playback button
            if playing {
                if ui.button("Stop Playback").clicked() {
                    self.is_playing.store(false, Ordering::Relaxed);
                    self.should_cleanup_playback = true;
                }
            } else if !recording && ui.button("Play").clicked() {
                let is_playing = Arc::clone(&self.is_playing);
                self.is_playing.store(true, Ordering::Relaxed);
                self.playback_thread = Some(thread::spawn(move || {
                    match playback_audio("output.wav", is_playing) {
                        Ok(_) => println!("Playback completed successfully"),
                        Err(e) => eprintln!("Error during playback: {:?}", e),
                    }
                }));
            }

            // Show recording/playing status
            if recording {
                ui.label("Recording in progress...");
            }
            if playing {
                ui.label("Playback in progress...");
            }
        });

        // Request continuous updates while recording or playing
        if self.is_recording.load(Ordering::Relaxed) || self.is_playing.load(Ordering::Relaxed) {
            ctx.request_repaint();
        }
    }
}

fn main() {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([300.0, 200.0]),
        ..Default::default()
    };
    
    eframe::run_native(
        "Audio Recorder",
        options,
        Box::new(|_cc| Box::new(AudioApp::default())),
    ).unwrap();
}
